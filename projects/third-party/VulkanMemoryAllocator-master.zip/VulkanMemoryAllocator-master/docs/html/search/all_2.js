var searchData=
[
  ['choosing_20memory_20type_0',['Choosing memory type',['../choosing_memory_type.html',1,'index']]],
  ['configuration_1',['Configuration',['../configuration.html',1,'index']]],
  ['custom_20memory_20pools_2',['Custom memory pools',['../custom_memory_pools.html',1,'index']]]
];
